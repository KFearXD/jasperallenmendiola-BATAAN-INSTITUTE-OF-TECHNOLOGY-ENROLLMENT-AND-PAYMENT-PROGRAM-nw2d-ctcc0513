/*Bataan Institute of Technology OOB Programming*/
package bit_finalreq;

import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.Stack;

public class bataaninsttech extends Frame {

    // Stack creation section
    private Stack<FormState> undoStack;
    private Stack<FormState> redoStack;
    FormState formState;
    
    // ArrayLists addition section
    private ArrayList<String> personalInfoFields;
    private ArrayList<String> motherInfoFields;
    private ArrayList<String> fatherInfoFields;
    private ArrayList<String> birthdayFields;
    private ArrayList<String> addressFields;
    private ArrayList<String> enrollmentFields;

    // AWT and Swing variables declaration section
    Label proglbl1, proglbl2, titlelbl1, titlelbl2, titlelbl3, perInfo, lname, fname, mname, sex, cpNum, bday, month, day, year, momInfo, momlname, 
    momfname, mommname, dadInfo, dadlname, dadfname, dadmname, email, address, addr1, addr2, addr3, addr4, addr5, enrollInfo1, enrollInfo2, 
    paymentlbl, descrip1, descrip2, changelbl, ttlAmount, backgr, mblMethod, mblNum, cash, php, yellowbgr, warn1, warn2, warn3, warn4, warn5;
    TextField lnameText, fnameText, mnameText, cpNumText, momlnameText, momfnameText, mommnameText, dadlnameText, dadfnameText, dadmnameText, 
    emailText, addr1Text, addr2Text, addr3Text, addr4Text, addr5Text, mblNumText, phpText;
    private Choice sexChoices, months, days, years, mblMethodChoice;
    Button itButton, csButton, emcButton, saveandpayButton, seeButton, retButton, unseeButton, redoButton;
    public static int change;
    private String selectedProgram = "";
    int tuitionFee = 7000;
    int totalFees;
    int miscellaneousFee1 = 5000;
    int miscellaneousFee2 = 6000;
    int miscellaneousFee1add = 7000+5000;
    int miscellaneousFee2add = 7000+6000;
    
    private class FormState {
        
        // These variables are for converting String to ArrayList
        private String lname;
        private String fname;
        private String mname;
        private String momlname;
        private String momfname;
        private String mommname;
        private String dadlname;
        private String dadfname;
        private String dadmname;
        private String emailText;
        private String sexChoice;
        private String cpNum;
        private String monthChoice;
        private String dayChoice;
        private String yearChoice;
        private String addr1;
        private String addr2;
        private String addr3;
        private String addr4;
        private String addr5;
        private String selectedProgram;

        // This constructors is for capturing the state
        public FormState(String lname, String fname, String mname, String momlname, String momfname, String mommname,
                String dadlname, String dadfname, String dadmname, String emailText, String sexChoice, String cpNum,
                String monthChoice, String dayChoice, String yearChoice, String addr1, String addr2,
                String addr3, String addr4, String addr5, String selectedProgram) {
            this.lname = lname;
            this.fname = fname;
            this.mname = mname;
            this.momlname = momlname;
            this.momfname = momfname;
            this.mommname = mommname;
            this.dadlname = dadlname;
            this.dadfname = dadfname;
            this.dadmname = dadmname;
            this.emailText = emailText;
            this.sexChoice = sexChoice;
            this.cpNum = cpNum;
            this.monthChoice = monthChoice;
            this.dayChoice = dayChoice;
            this.yearChoice = yearChoice;
            this.addr1 = addr1;
            this.addr2 = addr2;
            this.addr3 = addr3;
            this.addr4 = addr4;
            this.addr5 = addr5;
            this.selectedProgram = selectedProgram;
        }
    }

    public void Awt_variables() {
        setLayout(null); // Frame Setup

        // Components Section
        titlelbl1 = new Label("B A T A A N      I N S T I T U T E      O F      T E C H N O L O G Y", Label.CENTER);
        titlelbl2 = new Label("The faculty of BIT greets you with a warm gratitude for enrolling in this institution.", Label.CENTER);
        titlelbl3 = new Label("Please fill out this Enrollment Form properly in order to be officially enrolled for the upcoming semester.", Label.CENTER);

        perInfo = new Label("PERSONAL INFORMATION", Label.CENTER);
        lname = new Label("LAST Name: ");
        lnameText = new TextField("");
        fname = new Label("FIRST Name: ");
        fnameText = new TextField("");
        mname = new Label("MIDDLE Name: ");
        mnameText = new TextField("");
        momInfo = new Label("MOTHER'S FULL NAME (MAIDEN NAME)", Label.CENTER);
        momlname = new Label("Mother's LAST Name:");
        momlnameText = new TextField("");
        momfname = new Label("Mother's FIRST Name: ");
        momfnameText = new TextField("");
        mommname = new Label("Mother's MIDDLE Name: ");
        mommnameText = new TextField("");
        dadInfo = new Label("FATHER'S FULL NAME", Label.CENTER);
        dadlname = new Label("Father's LAST Name:");
        dadlnameText = new TextField("");
        dadfname = new Label("Father's FIRST Name: ");
        dadfnameText = new TextField("");
        dadmname = new Label("Father's MIDDLE Name: ");
        dadmnameText = new TextField("");

        sex = new Label("SEX: ");
        sexChoices = new Choice();
        sexChoices.add("");
        sexChoices.add("Male");
        sexChoices.add("Female");
        sexChoices.add("Rather Not Specify");
        cpNum = new Label("Mobile Number:");
        cpNumText = new TextField("");
        email = new Label("EMAIL ADDRESS: ");
        emailText = new TextField("");

        bday = new Label("BIRTHDAY", Label.CENTER);
        month = new Label("Month", Label.CENTER);
        
        months = new Choice();
        String[] monthsArray = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        for (String month : monthsArray) {
            months.add(month);
        }
        
        day = new Label("Day", Label.CENTER);
        days = new Choice();
        for (int t = 1; t <= 31; t++) {
            days.add(String.valueOf(t));
        }
        
        year = new Label("Year", Label.CENTER);
        years = new Choice();
        for (int t = 1980; t <= 2010; t++) {
            years.add(String.valueOf(t));
        }
        
        address = new Label("ADDRESS", Label.CENTER);
        addr1 = new Label("House Number and Street:");
        addr1Text = new TextField("");
        addr2 = new Label("Barangay:");
        addr2Text = new TextField("");
        addr3 = new Label("Municipality:");
        addr3Text = new TextField("");
        addr4 = new Label("Zip Code:");
        addr4Text = new TextField("");
        addr5 = new Label("Province:");
        addr5Text = new TextField();
        warn1 = new Label ("REMINDER", Label.CENTER);
        warn2 = new Label ("N/A", Label.CENTER);
        warn3 = new Label ("Simply write               if a middle name is unavailable", Label.CENTER);
        warn4 = new Label ("NUMERICAL", Label.CENTER);
        warn5 = new Label ("Make sure that the Zip Code is                                         ", Label.CENTER);

        enrollInfo1 = new Label("ENROLLMENT INFORMATION", Label.CENTER);
        enrollInfo2 = new Label("Kindly choose your desired college program below", Label.CENTER);
        itButton = new Button("Information Technology");
        csButton = new Button("Computer Science");
        emcButton = new Button("Entmt & Multimedia Computing");

        proglbl1 = new Label();
        descrip1 = new Label();
        descrip2 = new Label();
        paymentlbl = new Label("ONLINE PAYMENT");
        proglbl2 = new Label();
        paymentlbl.setAlignment(Label.CENTER);
        proglbl2.setAlignment(Label.CENTER);
        proglbl1.setAlignment(Label.CENTER);
        descrip1.setAlignment(Label.CENTER);
        descrip2.setAlignment(Label.CENTER);
        mblMethod = new Label("Mobile Payment Channel:");
        mblMethodChoice = new Choice();
        mblMethodChoice.add("");
        mblMethodChoice.add("GCash");
        mblMethodChoice.add("PayMaya");
        mblMethodChoice.add("BDO");
        mblNum = new Label("Username Pin:");
        mblNumText = new TextField();
        cash = new Label("Cash Amount:");
        php = new Label("Php");
        phpText = new TextField();
        ttlAmount = new Label();
        ttlAmount.setAlignment(Label.CENTER);
        changelbl = new Label();
        changelbl.setAlignment(Label.CENTER);
        backgr = new Label();
        saveandpayButton = new Button("SAVE AND PAY");
        seeButton = new Button("SEE SUMMARY");
        retButton = new Button("RETURN");
        unseeButton = new Button("UNSEE");
        redoButton = new Button("REPEAT");
        yellowbgr = new Label("");
        
        // Component Adding
        add(proglbl1);
        add(proglbl2);
        add(paymentlbl);
        add(descrip1);
        add(descrip2);
        add(mblMethod);
        add(mblMethodChoice);
        add(mblNum);
        add(mblNumText);
        add(cash);
        add(php);
        add(phpText);
        add(ttlAmount);
        add(changelbl);
        add(backgr);
        add(titlelbl1);
        add(titlelbl2);
        add(titlelbl3);
        add(perInfo);
        add(lname);
        add(lnameText);
        add(fname);
        add(fnameText);
        add(mname);
        add(mnameText);
        add(momInfo);
        add(momlname);
        add(momlnameText);
        add(momfname);
        add(momfnameText);
        add(mommname);
        add(mommnameText);
        add(dadInfo);
        add(dadlname);
        add(dadlnameText);
        add(dadfname);
        add(dadfnameText);
        add(dadmname);
        add(dadmnameText);
        add(email);
        add(emailText);
        add(bday);
        add(month);
        add(months);
        add(day);
        add(days);
        add(year);
        add(years);
        add(address);
        add(addr1);
        add(addr1Text);
        add(addr2);
        add(addr2Text);
        add(addr3);
        add(addr3Text);
        add(addr4);
        add(addr4Text);
        add(addr5);
        add(addr5Text);
        add(enrollInfo1);
        add(enrollInfo2);
        add(itButton);
        add(csButton);
        add(emcButton);
        add(sex);
        add(cpNum);
        add(cpNumText);
        add(sexChoices);
        add(saveandpayButton);
        add(seeButton);
        add(redoButton);
        add(unseeButton);
        add(retButton);
        add(yellowbgr);
        add(warn1);
        add(warn2);
        add(warn3);
        add(warn4);
        add(warn5);

        // Font Designing section
        Font labelFont = new Font("SERIF", Font.BOLD, 30);
            titlelbl1.setFont(labelFont);

        Font labelFont1 = new Font("Arial", Font.BOLD, 18);
            perInfo.setFont(labelFont1);
            momInfo.setFont(labelFont1);
            dadInfo.setFont(labelFont1);
            bday.setFont(labelFont1);
            address.setFont(labelFont1);
            enrollInfo1.setFont(labelFont1);
            paymentlbl.setFont(labelFont1);
            
        Font labelFont2 = new Font("Arial", Font.BOLD, 30);
            perInfo.setFont(labelFont2);
            
        Font labelFont3 = new Font("Arial", Font.BOLD, 10);
            lname.setFont(labelFont3);
            fname.setFont(labelFont3);
            mname.setFont(labelFont3);
            momlname.setFont(labelFont3);
            momfname.setFont(labelFont3);
            mommname.setFont(labelFont3);
            dadlname.setFont(labelFont3);
            dadfname.setFont(labelFont3);
            dadmname.setFont(labelFont3);
            email.setFont(labelFont3);
            sex.setFont(labelFont3);
            cpNum.setFont(labelFont3);
            month.setFont(labelFont3);
            day.setFont(labelFont3);
            year.setFont(labelFont3);
            addr1.setFont(labelFont3);
            addr2.setFont(labelFont3);
            addr3.setFont(labelFont3);
            addr4.setFont(labelFont3);
            addr5.setFont(labelFont3);
            warn3.setFont(labelFont3);
            warn5.setFont(labelFont3);
            
        Font labelFont4 = new Font("Serif", Font.BOLD, 20);
            warn1.setFont(labelFont4);
            warn2.setFont(labelFont4);
            warn4.setFont(labelFont4);
        
        Font btnFont = new Font("SERIF", Font.BOLD, 13);
            itButton.setFont(btnFont);
            csButton.setFont(btnFont);
            emcButton.setFont(btnFont);
            saveandpayButton.setFont(btnFont);
            seeButton.setFont(btnFont);
            redoButton.setFont(btnFont);
            unseeButton.setFont(btnFont);
            retButton.setFont(btnFont);

        Font progFont = new Font("Arial", Font.BOLD, 12);
            proglbl1.setFont(progFont);
            titlelbl2.setFont(progFont);
            titlelbl3.setFont(progFont);

        Font paymentFont = new Font("Dialog", Font.BOLD, 13);
            mblMethod.setFont(paymentFont);
            mblNum.setFont(paymentFont);
            cash.setFont(paymentFont);
            php.setFont(paymentFont);
            ttlAmount.setFont(paymentFont);
            changelbl.setFont(paymentFont);
            
        // Color Palette Customization section
        Color yellow = new Color(225, 173, 1);
            titlelbl1.setForeground(yellow);
            seeButton.setBackground(yellow);
            unseeButton.setBackground(yellow);
            retButton.setBackground(yellow);
            yellowbgr.setBackground(yellow);
        
        Color honeydew = new Color(240, 255, 240);
            enrollInfo1.setBackground(honeydew);
            enrollInfo2.setBackground(honeydew);
            proglbl1.setBackground(honeydew);
            descrip1.setBackground(honeydew);
            descrip2.setBackground(honeydew);
            ttlAmount.setBackground(honeydew);
            mblMethod.setBackground(honeydew);
            changelbl.setBackground(honeydew);
            
        Color pickle = new Color(150, 204, 91);
            csButton.setBackground(pickle);
        
        Color moss = new Color(173, 223, 173);
            itButton.setBackground(moss);
       
        Color olive = new Color(107, 142, 35);
            emcButton.setBackground(olive);
        
        Color spring = new Color(115, 165, 128);
            titlelbl1.setBackground(spring);
            titlelbl2.setBackground(spring);
            titlelbl3.setBackground(spring);
        
        Color flavescent = new Color(240, 237, 153);
            perInfo.setBackground(flavescent);
            momInfo.setBackground(flavescent);
            dadInfo.setBackground(flavescent);
            bday.setBackground(flavescent);
            address.setBackground(flavescent);

        Color paleGold = new Color(219, 208, 134);
            lname.setBackground(paleGold);
            fname.setBackground(paleGold);
            mname.setBackground(paleGold);
            momlname.setBackground(paleGold);
            momfname.setBackground(paleGold);
            mommname.setBackground(paleGold);
            dadlname.setBackground(paleGold);
            dadfname.setBackground(paleGold);
            dadmname.setBackground(paleGold);
            email.setBackground(paleGold);
            sex.setBackground(paleGold);
            cpNum.setBackground(paleGold);
            month.setBackground(paleGold);
            day.setBackground(paleGold);
            year.setBackground(paleGold);
            addr1.setBackground(paleGold);
            addr2.setBackground(paleGold);
            addr3.setBackground(paleGold);
            addr4.setBackground(paleGold);
            addr5.setBackground(paleGold);
            redoButton.setBackground(paleGold);
        
        Color lightMint = new Color(152, 245, 158);
            proglbl2.setBackground(lightMint);
            paymentlbl.setBackground(lightMint);
            mblMethod.setBackground(lightMint);
            mblNum.setBackground(lightMint);
            php.setBackground(lightMint);
            cash.setBackground(lightMint);
            backgr.setBackground(lightMint);
            saveandpayButton.setBackground(lightMint);
           
        Color powder = new Color(255, 220, 104);
            warn1.setBackground(powder);
            warn2.setBackground(powder);
            warn3.setBackground(powder);
            warn4.setBackground(powder);
            warn5.setBackground(powder);

        // Setting Bounds and Background Colors section
        titlelbl1.setBounds(25, 40, 1480, 30);
        titlelbl2.setBounds(25, 70, 1480, 20);
        titlelbl3.setBounds(25, 90, 1480, 20);
        perInfo.setBounds(25, 120, 900, 50);
        lname.setBounds(25, 180, 90, 50);
        lnameText.setBounds(125, 180, 400, 50);
        fname.setBounds(25, 240, 90, 50);
        fnameText.setBounds(125, 240, 400, 50);
        mname.setBounds(25, 300, 90, 50);
        mnameText.setBounds(125, 300, 400, 50);
        momInfo.setBounds(25, 370, 500, 40);
        momlname.setBounds(25, 420, 140, 30);
        momlnameText.setBounds(175, 420, 350, 30);
        momfname.setBounds(25, 460, 140, 30);
        momfnameText.setBounds(175, 460, 350, 30);
        mommname.setBounds(25, 500, 140, 30);
        mommnameText.setBounds(175, 500, 350, 30);
        dadInfo.setBounds(25, 550, 500, 40);
        dadlname.setBounds(25, 600, 140, 30);
        dadlnameText.setBounds(175, 600, 350, 30);
        dadfname.setBounds(25, 640, 140, 30);
        dadfnameText.setBounds(175, 640, 350, 30);
        dadmname.setBounds(25, 680, 140, 30);
        dadmnameText.setBounds(175, 680, 350, 30);
        sex.setBounds(550, 180, 33, 20);
        sexChoices.setBounds(593, 180, 120, 20);
        cpNum.setBounds(730, 180, 85, 20);
        cpNumText.setBounds(825, 180, 100, 20);
        email.setBounds(550, 210, 100, 20);
        emailText.setBounds(660, 210, 265, 20);  
        bday.setBounds(550, 240, 375, 40);
        month.setBounds(550, 290, 120, 30);
        months.setBounds(550, 330, 120, 30);
        day.setBounds(676, 290, 122, 30);
        days.setBounds(676, 330, 122, 30);
        year.setBounds(805, 290, 120, 30);
        years.setBounds(805, 330, 120, 30);
        address.setBounds(550, 360, 375, 40);
        addr1.setBounds(550, 410, 150, 30);
        addr1Text.setBounds(710, 410, 215, 30);
        addr2.setBounds(550, 450, 150, 30);
        addr2Text.setBounds(710, 450, 215, 30);
        addr3.setBounds(550, 490, 150, 30);
        addr3Text.setBounds(710, 490, 215, 30);
        addr4.setBounds(550, 530, 150, 30);
        addr4Text.setBounds(710, 530, 215, 30);
        addr5.setBounds(550, 570, 150, 30);
        addr5Text.setBounds(710, 570, 215, 30);
        enrollInfo1.setBounds(940, 120, 565, 30);
        enrollInfo2.setBounds(940, 150, 565, 20);
        itButton.setBounds(940, 180, 180, 90);
        csButton.setBounds(1133, 180, 180, 90);
        emcButton.setBounds(1326, 180, 180, 90);
        proglbl1.setBounds(940, 280, 565, 30);
        descrip1.setBounds(940, 310, 565, 30);
        descrip2.setBounds(940, 331, 565, 30);
        proglbl2.setBounds(940, 420, 565, 30);
        paymentlbl.setBounds(940, 380, 565, 30);
        mblMethod.setBounds(1055, 495, 160, 30);
        mblMethodChoice.setBounds(1230, 500, 170, 90);
        mblNum.setBounds(1122, 535, 94, 30);
        mblNumText.setBounds(1230, 540, 170, 20);
        cash.setBounds(1124, 575, 91, 30);
        php.setBounds(1230, 575, 30, 30);
        phpText.setBounds(1260, 580, 140, 20);
        ttlAmount.setBounds(963, 458, 520, 30);
        changelbl.setBounds(963, 612, 520, 30);
        saveandpayButton.setBounds(1385, 660, 120, 50);
        unseeButton.setBounds(1120, 660, 80, 50);
        retButton.setBounds(1030, 660, 80, 50);
        redoButton.setBounds(940, 660, 80, 50);
        seeButton.setBounds(1210, 660, 110, 50);
        backgr.setBounds(940, 450, 565, 200);
        yellowbgr.setBounds(-10, 730, 1600, 760);
        warn1.setBounds(550, 610, 375, 43);
        warn2.setBounds(670, 653, 37, 30);
        warn3.setBounds(550, 653, 375, 30);
        warn4.setBounds(757, 680, 125, 30);
        warn5.setBounds(550, 680, 375, 30);

        // Click in order to terminate the project
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    // Methods used to call other methods
    bataaninsttech() {
        undoStack = new Stack<>();
        redoStack = new Stack<>();
        
        // Used for calling methods
        Awt_variables();
        buttonfunctions();

        // Used to initialize the Arraylist
        personalInfoFields = new ArrayList<>();
        motherInfoFields = new ArrayList<>();
        fatherInfoFields = new ArrayList<>();
        birthdayFields = new ArrayList<>();
        addressFields = new ArrayList<>();
        enrollmentFields = new ArrayList<>();
    }

    // Methods use for the stacks and functionality of the code
    private void pushFormState() {

        // Update the ArrayLists with the current user input
        personalInfoFields.add(lnameText.getText());
        personalInfoFields.add(fnameText.getText());
        personalInfoFields.add(mnameText.getText());
        
        // Add other personal infomation fields similarly
        motherInfoFields.add(momlnameText.getText());
        motherInfoFields.add(momfnameText.getText());
        motherInfoFields.add(mommnameText.getText());
        
        // Add other mother infomation fields similarly
        fatherInfoFields.add(dadlnameText.getText());
        fatherInfoFields.add(dadfnameText.getText());
        fatherInfoFields.add(dadmnameText.getText());
        
        // Add other father infomation fields similarly
        birthdayFields.add((String) sexChoices.getSelectedItem());
        birthdayFields.add(cpNumText.getText());
        birthdayFields.add((String) months.getSelectedItem());
        birthdayFields.add((String) days.getSelectedItem());
        birthdayFields.add((String) years.getSelectedItem());
        
        // Add other address infomation fields similarly
        addressFields.add(addr1Text.getText());
        addressFields.add(addr2Text.getText());
        addressFields.add(addr3Text.getText());
        addressFields.add(addr4Text.getText());
        addressFields.add(addr5Text.getText());

        formState = new FormState(lnameText.getText(), fnameText.getText(), mnameText.getText(),
                momlnameText.getText(), momfnameText.getText(), mommnameText.getText(),
                dadlnameText.getText(), dadfnameText.getText(), dadmnameText.getText(),
                (String) sexChoices.getSelectedItem(), cpNumText.getText(), emailText.getText(),
                (String) months.getSelectedItem(), (String) days.getSelectedItem(), (String) years.getSelectedItem(),
                addr1Text.getText(), addr2Text.getText(), addr3Text.getText(), addr4Text.getText(), addr5Text.getText(),
                selectedProgram);

        enrollmentFields.add(selectedProgram);

        undoStack.push(formState); // Used to add all the value of formstate that goes into array list into the stack
    }

    // This is for displaying all the data that the stacks have
    private void displaystudentlist() {
        
        StringBuilder studentsInfo = new StringBuilder(); // This stringbuilder is used to append the array list

        if (!undoStack.isEmpty()){

            for (FormState state : undoStack){
                studentsInfo.append("Enrolled Student Information:\n");
                studentsInfo.append("              \n");
                studentsInfo.append("Last Name: ").append(state.lname).append("\n");
                studentsInfo.append("First Name: ").append(state.fname).append("\n");
                studentsInfo.append("Middle Name: ").append(state.mname).append("\n");
                studentsInfo.append("Sex: ").append(state.emailText).append("\n");
                studentsInfo.append("Selected Program: ").append(state.selectedProgram).append("\n");
                studentsInfo.append("              \n");
                studentsInfo.append("Your enrollment details and payment receipt\n");
                studentsInfo.append("has been successfully sent to your email address\n");
                studentsInfo.append("_____________________________________________\n");
            }
        } else {
            studentsInfo.append("Fill up the components first");
        }

        JOptionPane.showMessageDialog(this, studentsInfo.toString(), "Enrolled Students Information", JOptionPane.INFORMATION_MESSAGE);
    }


    private void undo() {
        if (!undoStack.isEmpty()) {
            redoStack.push(undoStack.pop());
            restoreFormState();
            displaystudentlist();
            printStackContents(undoStack, "undo");
        } else {
            // Displaying a pop-up message about the error
            JOptionPane.showMessageDialog(null, "Please, properly fill out the form first then save and pay", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void redo() {
        if (!redoStack.isEmpty()) {
            undoStack.push(redoStack.pop());
            restoreFormState();
            displaystudentlist();

            printStackContents(undoStack, "undo");
        } else {
            // Displaying a pop-up message about the error
            JOptionPane.showMessageDialog(null, "Please, properly fill out the form first then save and pay", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void restoreFormState() {
        if (!undoStack.isEmpty()) {
            FormState formState = undoStack.peek();
        }
    }

    // This is to create a method used for the button functionalities of the project
    public void buttonfunctions() {

        itButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                proglbl1.setText("You have chosen Bachelor of Science in Information Technology");
                descrip1.setText("It is a four-year degree program that equips students with the basic ability to conceptualize,");
                descrip2.setText("design and implement software appplications.");
                proglbl2.setText("Tuition Fee: Php " + tuitionFee + "               Miscellaneous Fee: Php " + miscellaneousFee1);
                ttlAmount.setText("The total payment would be Php " + miscellaneousFee1add);
                selectedProgram = "Information Technology";
            }
        });

        csButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                proglbl1.setText("You have chosen Bachelor of Science in Computer Science");
                descrip1.setText("It is a four-year program that includes the study of computing methods and theories, algorithmic");
                descrip2.setText("foundations and new developments in computing.");
                proglbl2.setText("Tuition Fee: Php " + tuitionFee + "               Miscellaneous Fee: Php " + miscellaneousFee1);
                ttlAmount.setText("The total payment would be Php " + miscellaneousFee1add);
                selectedProgram = "Computer Science";
            }
        });

        emcButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                proglbl1.setText("You have chosen Bachelor of Science in Entertainment and Multimedia Computing");
                descrip1.setText("It is a four-year degree program that studies the use of concepts, principles and techniques of ");
                descrip2.setText("computing in the design and development of multimedia products and solutions.");
                proglbl2.setText("Tuition Fee: Php " + tuitionFee + "               Miscellaneous Fee: Php " + miscellaneousFee2);
                ttlAmount.setText("The total payment would be Php " + miscellaneousFee2add);
                selectedProgram = "Entmt & Multimedia Computing";
            }
        });

        saveandpayButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (lnameText.getText().isEmpty() || fnameText.getText().isEmpty()
                        || mnameText.getText().isEmpty() || cpNumText.getText().isEmpty()
                        || momlnameText.getText().isEmpty() || momfnameText.getText().isEmpty()
                        || mommnameText.getText().isEmpty() || dadlnameText.getText().isEmpty()
                        || dadfnameText.getText().isEmpty() || dadmnameText.getText().isEmpty()
                        || addr1Text.getText().isEmpty() || addr2Text.getText().isEmpty()
                        || addr3Text.getText().isEmpty() || addr4Text.getText().isEmpty()
                        || addr5Text.getText().isEmpty() || mblNumText.getText().isEmpty()
                        || phpText.getText().isEmpty() || emailText.getText().isEmpty()){
                    // Displaying a pop-up message about the error
                    JOptionPane.showMessageDialog(null, "Please, fill up all of the components", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        int payment = Integer.parseInt(phpText.getText());

                        if (selectedProgram.equals("Information Technology") || selectedProgram.equals("Computer Science")) {
                            totalFees = tuitionFee + miscellaneousFee1;
                        } else if (selectedProgram.equals("Entmt & Multimedia Computing")) {
                            totalFees = tuitionFee + miscellaneousFee2;
                        }
                        if (payment >= totalFees) {
                            int change = payment - totalFees;
                            changelbl.setText("Your payment and change worth Php " + change + " is successfully received and returned.");

                            pushFormState(); // This is used to add all the imformation of the user into the stacks
                        } else {
                            changelbl.setText("Insufficient payment. Please enter an amount equal to or higher than the total payment.");
                        }

                    } catch (NumberFormatException ex) {
                        // Handle the case where the input is not a valid integer
                        changelbl.setText("Invalid input. Please enter a valid numeric amount.");
                    }
                }
            }
        });

        retButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                redo();
            }
        });

        seeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displaystudentlist();
            }
        });

        unseeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                undo();
            }
        });
        
        redoButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                lnameText.setText("");
                fnameText.setText("");
                mnameText.setText("");
                momlnameText.setText("");
                momfnameText.setText("");
                mommnameText.setText("");
                dadlnameText.setText("");
                dadfnameText.setText("");
                dadmnameText.setText("");
                emailText.setText("");
                cpNumText.setText("");
                addr1Text.setText("");
                addr2Text.setText("");
                addr3Text.setText("");
                addr4Text.setText("");
                addr5Text.setText("");
                sexChoices.select(0);
                months.select(0);
                days.select(0);
                years.select(0);
                proglbl1.setText("");
                proglbl2.setText("");
                descrip1.setText("");
                descrip2.setText("");
                mblMethodChoice.select(0);
                mblNumText.setText("");
                phpText.setText("");
                ttlAmount.setText("");
                changelbl.setText("");
                backgr.setText("");
                
                while(!undoStack.isEmpty()){
                    redoStack.push(undoStack.pop());
                    restoreFormState();
                }
            }
        });
    }

    // This is used for debugging of the stack to see its value
    private void printStackContents(Stack<FormState> stack, String stackName) {
        System.out.println("Contents of " + stackName + " stack:");
        for (FormState state : stack) {
            System.out.println(state.toString());
        }
        System.out.println("-------------------------");
    }

    public static void main(String[] args) {
        bataaninsttech Bataan_Inst_Tech = new bataaninsttech();
        Bataan_Inst_Tech.setVisible(true);
        Color spring = new Color(115, 165, 128);
        Bataan_Inst_Tech.setBackground(spring);
    }
}